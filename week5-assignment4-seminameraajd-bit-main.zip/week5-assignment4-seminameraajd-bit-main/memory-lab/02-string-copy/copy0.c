#include <cs50.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h> // Required for malloc and free
#include <string.h>

int main(void)
{
    string s = get_string("s: ");

    // Allocate enough memory for a copy (including the null terminator)
    char *t = malloc(strlen(s) + 1);

    // Copy the string from s into the new memory at t
    strcpy(t, s);

    // Now changing t does NOT affect s
    if (strlen(t) > 0)
    {
        t[0] = toupper(t[0]);
    }

    printf("s: %s\n", s);
    printf("t: %s\n", t);

    // Don't forget to free memory!
    free(t);
}