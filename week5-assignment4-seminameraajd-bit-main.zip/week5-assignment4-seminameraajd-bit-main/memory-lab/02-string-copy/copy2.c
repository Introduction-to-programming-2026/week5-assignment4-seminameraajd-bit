#include <cs50.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void)
{
    // Get a string
    char *s = get_string("s: ");

    // 1. Allocate memory: length of s + 1 for the null terminator '\0'
    char *t = malloc(strlen(s) + 1);

    // 2. Copy each character from s into t
    for (int i = 0; i <= strlen(s); i++)
    {
        t[i] = s[i];
    }

    // 3. Capitalize the first letter of t only (safety check included)
    if (strlen(t) > 0)
    {
        t[0] = toupper(t[0]);
    }

    // Print results
    printf("s: %s\n", s);
    printf("t: %s\n", t);

    // Good practice: free the memory you allocated!
    free(t);
}