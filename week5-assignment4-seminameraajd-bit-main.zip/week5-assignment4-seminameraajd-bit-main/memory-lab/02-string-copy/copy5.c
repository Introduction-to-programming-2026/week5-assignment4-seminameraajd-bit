#include <cs50.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void)
{
    // Get a string
    char *s = get_string("s: ");

    // Check if get_string returned NULL (e.g., user pressed Ctrl-D)
    if (s == NULL)
    {
        return 1;
    }

    // Allocate memory for t
    char *t = malloc(strlen(s) + 1);

    // Check if t is NULL (if the computer has no memory left to give)
    if (t == NULL)
    {
        return 1;
    }

    // Copy s into t using strcpy (destination first, then source)
    strcpy(t, s);

    // Capitalize t[0] only if the string is not empty
    if (strlen(t) > 0)
    {
        t[0] = toupper(t[0]);
    }

    // Print both strings
    printf("s: %s\n", s);
    printf("t: %s\n", t);

    // Free the memory you allocated to prevent a memory leak
    free(t);

    return 0;
}