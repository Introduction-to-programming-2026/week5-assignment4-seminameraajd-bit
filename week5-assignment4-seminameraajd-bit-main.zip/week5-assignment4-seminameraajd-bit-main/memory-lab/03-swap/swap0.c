#include <stdio.h>

// Change the prototype to accept pointers (addresses)
void swap(int *a, int *b);

int main(void)
{
    int x = 1;
    int y = 2;

    printf("x is %i, y is %i\n", x, y);
    
    // Pass the ADDRESSES of x and y using the & operator
    swap(&x, &y);
    
    printf("x is %i, y is %i\n", x, y);
}

// Function receives the addresses and stores them in pointers a and b
void swap(int *a, int *b)
{
    // Go to the address in 'a' and grab the value to put in tmp
    int tmp = *a;
    
    // Go to the address in 'b' and copy its value to the address in 'a'
    *a = *b;
    
    // Put the tmp value into the address in 'b'
    *b = tmp;
}