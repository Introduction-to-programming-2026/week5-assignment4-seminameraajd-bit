#include <stdio.h>

// 1. Update signature: parameters are now pointers to integers
void swap(int *a, int *b);

int main(void)
{
    int x = 1;
    int y = 2;

    printf("x is %i, y is %i\n", x, y);

    // 2. Pass the ADDRESSES of x and y using the & operator
    swap(&x, &y);

    printf("x is %i, y is %i\n", x, y);
}

// 3. Update the function body to use pointers
void swap(int *a, int *b)
{
    // Go to the address stored in 'a' and store that value in 'tmp'
    int tmp = *a;
    
    // Go to the address in 'b', get that value, and move it to the address in 'a'
    *a = *b;
    
    // Take the value from 'tmp' and move it to the address stored in 'b'
    *b = tmp;
}