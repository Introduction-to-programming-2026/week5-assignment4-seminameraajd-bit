#include <stdio.h>

typedef unsigned char BYTE;

int main(int argc, char *argv[])
{
    // Ensure the user provided exactly two arguments (source and destination)
    if (argc != 3)
    {
        printf("Usage: ./cp source destination\n");
        return 1;
    }

    // 1. Open source file for reading in binary mode ("rb")
    FILE *src = fopen(argv[1], "rb");
    if (src == NULL)
    {
        printf("Could not open source file.\n");
        return 1;
    }

    // 2. Open destination file for writing in binary mode ("wb")
    FILE *dst = fopen(argv[2], "wb");
    if (dst == NULL)
    {
        printf("Could not open destination file.\n");
        fclose(src); // Clean up the source before exiting
        return 1;
    }

    BYTE b;

    // 3. Loop: read one BYTE from src, write it to dst
    // fread/fwrite take the address of the buffer (&b)
    while (fread(&b, sizeof(b), 1, src) != 0)
    {
        fwrite(&b, sizeof(b), 1, dst);
    }

    // 4. Close both files to save changes and free system resources
    fclose(src);
    fclose(dst);

    return 0;
}