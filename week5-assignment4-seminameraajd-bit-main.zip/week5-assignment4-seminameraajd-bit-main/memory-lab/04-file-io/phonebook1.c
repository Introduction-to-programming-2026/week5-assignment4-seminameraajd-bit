#include <cs50.h>
#include <stdio.h>
#include <string.h>

int main(void)
{
    // 1. Open "phonebook.csv" in append mode "a"
    FILE *file = fopen("phonebook.csv", "a");

    // 2. Check if fopen returned NULL (safety check)
    if (file == NULL)
    {
        return 1;
    }

    // Get name and number from the user
    char *name = get_string("Name: ");
    char *number = get_string("Number: ");

    // 3. Write name and number to the file in CSV format
    // CSV stands for Comma-Separated Values
    fprintf(file, "%s,%s\n", name, number);

    // 4. Close the file to ensure data is saved
    fclose(file);

    return 0;
}